All the following are from [the Noun Project](https://thenounproject.com) licenced under either Creative Commons or Public Domain

* [alien] (https://thenounproject.com/term/alien/1820539) by Minh Do
* [raygun] (https://thenounproject.com/term/raygun/11236/) by Dominik Grob
* [vr] (https://thenounproject.com/term/vr/2334639) by Mahmure Alp
* [Human cloning ] (https://thenounproject.com/term/human-cloning/1581556/) by Gan Khoon Lay 

The following is from [freesound] (https://freesound.org) licensed under the Creative Commons 0 License. 
* [phaser] modified from (https://freesound.org/people/IanStarGem/sounds/341831/) by IanStarGem
